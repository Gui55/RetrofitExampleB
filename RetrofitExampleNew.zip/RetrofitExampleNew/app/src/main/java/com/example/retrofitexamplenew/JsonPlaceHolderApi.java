package com.example.retrofitexamplenew;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

//Interface API de Json

public interface JsonPlaceHolderApi {

    @GET("posts")
    Call<List<Post>> getPosts();

}
